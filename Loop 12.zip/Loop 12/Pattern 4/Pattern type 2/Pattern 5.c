/*
  ......
  ......
  1 2 3
  1 2
  1    ; here we print col;
*/

#include<stdio.h>
int main()
{
    int n, row, col;
    printf("Enter n : ");
    scanf("%d",&n);

    for(row=n; row>=1; row--)
    {
        for(col=1; col<=row; col++)
        {
            printf("%c ",col+64);  // row print;
        }
        printf("\n");
    }

    return 0;
}






