// Write a C Program that checks a number is Armstrong 1 to 1000;

#include<stdio.h>
int main()
{
    int temp,r,sum = 0,i;
    for(i=1; i<=1000; i++)
    {
        temp = i;

    while(temp != 0)
    {

        r = temp%10;
        sum = sum + r*r*r;
        temp = temp/10;
    }

    if(sum == i)
    {

        printf("Armstrong = %d\n",i);
    }
    sum = 0;

    }



    return 0;
}


