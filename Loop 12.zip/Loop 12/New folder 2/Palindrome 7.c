//Write a C Program that checks an integer numbers is palindrome or not;
// input =  not same output   not palindrome number
// input = same output   is palindrome number

#include<stdio.h>
int main()
{
    int num,temp, r,sum = 0;
    printf("Enter any integer : ");
    scanf("%d",&num);

    temp = num;

    while(temp != 0)
    {

        r = temp%10;
        sum = sum * 10 + r;
        temp = temp/10;
    }
    printf("Reverse of number = %d\n",sum);

    if(num == sum)
        printf("The number is Palindrome\n");
    else
        printf("Not Palindrome\n");

    return 0;
}

