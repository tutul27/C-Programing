//Strong number is a special number whose sum of factorial of digits is equal to the original number.
// 145 = 1! + 4! + 5!;

#include<stdio.h>
int main()
{
    int num,temp, r,sum = 0;
    printf("Enter any integer : ");
    scanf("%d",&num);

    temp = num;

    while(temp != 0)
    {

        r = temp%10;
        sum = sum + r;
        temp = temp/10;
    }
    printf("Sum Of digits = %d\n",sum);

    return 0;
}

