//1^1 * 2^2 * 3^3......n^n;
//1^1 * 3^3 * 5^5......n^n;
//2^2 * 4^4 * 6^6......n^n;
#include<stdio.h>
int main()
{
    int i, n, result = 1;
    printf("Enter n : ");
    scanf("%d",&n);



    for(i=1; i<=n; i++)
    {
        result = result * i*i;
    }

    printf("Result   = %d",result);
    return 0;
}
