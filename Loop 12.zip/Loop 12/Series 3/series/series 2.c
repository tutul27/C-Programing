// 1 + 2 + 3 + .......+ N;
// 2 + 4 + 6 + .......+ N;  a=2; a= a+2;
// while

#include<stdio.h>
int main()
{
    int num, sum = 0, a = 1;
    printf("Enter the last number of the series : ");
    scanf("%d",&num);
    printf("1 + 2 + 3 + .......+ %d",num);


    while( a <= num )
        {
            sum = sum + a;
            a = a + 1;
        }
    printf(" = %d\n",sum);

    return 0;
}
