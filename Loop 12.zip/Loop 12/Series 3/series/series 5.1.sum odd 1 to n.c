
//1+3+5+........+ n;(Sum of odd numbers 1 to n); print

#include<stdio.h>
int main()
{
    int n, i, sum = 0;
    printf("Enter number n : ");
    scanf("%d",&n);


    printf("1 + 3 + 5 + 7+........%d\n",n);

    for(i = 1; i<=n; i=i+2)
    {
        sum = sum + i;
    }
    printf(" Sum of %d numbers = %d",n,sum);


    return 0;
}
