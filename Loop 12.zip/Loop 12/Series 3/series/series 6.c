// 1.5 + 2.5 + 3.5 + 4.5+ .....+ N;

#include<stdio.h>
int main()
{

    float i, n, sum = 0;
    printf("Enter n : ");
    scanf("%f",&n);

    printf("1.5 + 2.5 + 3.5 + ........%d\n",n);

    for(i = 1.5; i<=n; i++)
    {
        sum = sum + i;
    }
    printf(" Sum = %.2f",sum);
    return 0;
}
