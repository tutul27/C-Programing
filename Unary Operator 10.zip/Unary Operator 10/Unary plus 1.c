//Write a C Program that that use unary plus operator

#include<stdio.h>
int main()
{
    int result,  x = 10;
    result = +x;

    printf("Result of unary plus Operator = %d",result);

    return 0;
}
