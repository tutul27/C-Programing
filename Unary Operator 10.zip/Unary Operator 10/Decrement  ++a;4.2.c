//Use of post increment
// a++;
//increment x by one - after it is used

#include<stdio.h>
int main()
{
    int y,x = 10;

    y = x++; //y = 10; replace
    printf("x = %d\n",x);
    printf("y = %d\n",y);
    return 0;
}

