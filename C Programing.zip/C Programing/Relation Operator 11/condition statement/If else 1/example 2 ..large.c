//Write a C Program that read two value and display greater value;
#include<stdio.h>
int main()
{
    int time = 10;

    if(time == 10)
    {
        printf("Good Morning\n");
        printf("Tutul haque\n");
    }
    else
    {
        printf("Sorry its not good morning\n");
        printf("Tutul");
    }

    return 0;
}
