//Write a C Program that takes a number and display it is positive or negative or zero;

#include<stdio.h>
int main()
{
    int num;

    printf("Enter any integer number : ");
    scanf("%d",&num);

    if(num > 0)
    {
        printf("Number is positive ");
    }

     else if(num < 0)
    {
        printf("Number is negative n");
    }
    else
        printf("Number is zero ");

    return 0;
}
