//Enter a letter to cheek vowel or constant

#include<stdio.h>
int main()
{
    char ch;

    printf("Enter a letter : ");
    scanf("%c",&ch);


    if(ch == 'a' || ch == 'i' || ch == 'u' || ch == 'o' || ch == 'e')
    {
        printf("Vowel");
    }

    else
        printf("Constant");

    return 0;
}
