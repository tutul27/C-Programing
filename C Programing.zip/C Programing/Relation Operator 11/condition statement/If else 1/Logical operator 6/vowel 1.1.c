//Write a C Program that read a letter and print it vowel or constant

#include<stdio.h>
int main()
{
    char ch;
    printf("Enter a letter : ");
    scanf("%c",&ch);

    if(ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'o' ||
       ch == 'O' || ch == 'u' || ch == 'U' || ch == 'i' || ch == 'I')
    {
        printf("Vowel");
    }
    else
        printf("Constant");

    return 0;
}
