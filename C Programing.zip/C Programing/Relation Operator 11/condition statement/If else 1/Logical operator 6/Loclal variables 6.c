//Local variables declare one inside  function and it not use other function

#include<stdio.h>
int a = 10;//Global variable
int main()
{
    //int a = 10; //here a is a local variable;
    printf("Inside the main function %d\n ",a );
    display();
}
void display()
{
    printf("Inside the display function %d\n ",a );//error will be shown here;
}
