//Write a C Program that read two value and display greater value;
#include<stdio.h>
int main()
{
    int num1,num2;

    printf("Enter the first number : ");
    scanf("%d",&num1);

    printf("Enter the second number : ");
    scanf("%d",&num2);

    if(num1 > num2){
        printf("Large = %d\n",num1);
    }

    else if(num2 > num1){
        printf("Large = %d\n",num2);
    }
    else
        printf("Number is equal");



    return 0;
}
