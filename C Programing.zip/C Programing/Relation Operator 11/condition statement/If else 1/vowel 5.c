//take a character and display its vowel or constant;

#include<stdio.h>
int main()
{
    char ch;
    printf("Enter a letter :  ");
    scanf("%c",&ch);

    if(ch == 'a'){
        printf("Vowel");
    }

    else if(ch == 'o'){
        printf("Vowel");
    }

    else if(ch == 'u'){
        printf("Vowel");
    }

    else if(ch == 'i'){
        printf("Vowel");
    }

    else if(ch == 'e'){
        printf("Vowel");
    }

    else
        printf(" The letter is Constant");
    return 0;
}
