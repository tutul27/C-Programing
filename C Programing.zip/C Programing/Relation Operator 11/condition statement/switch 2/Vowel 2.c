//Write a C program that take a letter and display vowel or constant;
#include<stdio.h>
int main()
{

    char ch;
    printf("Enter any letter : ");
    scanf("%c",&ch);

    switch(ch)
    {
    case 'a':
    case 'A':
    case 'e':
    case 'E':
    case 'o':
    case 'O':
    case 'i':
    case 'I':
    case 'u':
    case 'U':
        printf("Vowel");
        break;

     default:
     printf("Constant");
    }
    return ;
}
