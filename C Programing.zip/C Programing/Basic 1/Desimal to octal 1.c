//Conversion between decimal to octal number  using by C Program
#include<stdio.h>
int main()
{
    int D_number;
    printf("Enter the Decimal number : ");
    scanf("%d",&D_number);

    printf("Octal number : %o",D_number);


    //Conversion between Octal to desimal;
    /*int D_number;
    printf("Enter the Octal number : ");
    scanf("%o",&D_number);

    printf("Decimal number : %d",D_number);
    return 0;
    */
}
