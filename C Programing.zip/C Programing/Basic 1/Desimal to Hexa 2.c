//Conversion between Decimal to  Hexadecimal

#include<stdio.h>
int main()
{
   //Decimal to Hexadecimal number
    int D_number;
    printf("Enter the Decimal number : ");
    scanf("%d",&D_number);

    printf("Hexadecimal number : %x",D_number);


    //Hexadecimal to Decimal
    /*
    int D_number;
    printf("Enter the Hexadecimal number : ");
    scanf("%x",&D_number);

    printf("Decimal number : %d",D_number);
    */



    //Conversion between Hexadecimal to Octal  number

      /*
    int D_number;
    printf("Enter the Hexadecimal number : ");
    scanf("%x",&D_number);

    printf("Octal number : %o",D_number);
    */



    return 0;
}
