// Area of a triangle;

#include<stdio.h>
double triangle(double b, double h)
{
    return .5 * b * h;
}




int main()
{
    double base,height;
    printf("Enter the base  : ");
    scanf("%lf",&base);

    printf("Enter the height  : ");
    scanf("%lf",&height);

    double area = triangle(base , height);
    printf("Area = %.2lf\n",area);
}
