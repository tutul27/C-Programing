//Write a C Program that passing an array to a function and find maximum value;

#include<stdio.h>
void displayArray(int x[])
{
    int i;
    int max = x[0];

     for(i=1; i<5; i++)
    {
        if(max < max[i])
        {
            max = max[i];
        printf("%d ",x[i]);
        }

    }
}
int main()

{
    int num[] = {10,20,30,40,50};
    displayArray(num);


}

