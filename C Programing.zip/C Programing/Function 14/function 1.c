#include<stdio.h>

void sum (int a, int b, int c)
{

    printf("The sum is : %d\n",a+b+c);
    printf("The sum is : %d\n",a+b-c);
}

void sub (int a, int b)
{
    printf("The sub is : %d\n",a-b);

}

int main()
{
    sum(30,20,30);
    sum(20,10,10);

    sub(20,30);
}
