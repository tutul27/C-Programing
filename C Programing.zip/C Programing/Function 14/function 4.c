// X to the power Y using User defined Function;

#include<stdio.h>
void calculatePower(double base,double exp)
{
    double result = 1,i;

    for(i=0; i<exp; i++)
    {
        result = result*base;
    }
    printf("Result base^exp = %.lf\n",result);
}
int main()
{

    double base, exp;

    printf("Enter base : ");
    scanf("%lf",&base);

    printf("Enter exp : ");
    scanf("%lf",&exp);

    calculatePower(base,exp);
    calculatePower(2,3);



}
