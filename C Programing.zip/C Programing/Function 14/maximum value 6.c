//finding maximum value from an array using function
//Write a C Program that passing an array to a function and find maximum value;

#include<stdio.h>
int maximum(int x[])
{
    int i;
    int max = x[0];
     for(i=1; i<5; i++)
    {
        if(max < x[i])
              max = x[i];

    }
    return max;
}
int main()

{
    int num[] = {10,20,30,40,50},i;
    int maximumVamue = maximum(num);
    printf("Maximum Value : %d",maximumVamue);


}

