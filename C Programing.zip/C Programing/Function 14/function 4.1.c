// x to the power y (using/ not using)Library function
//2^3 = 2*2*2;
// 3^3 = 3*3*3
// 2^4 = 2*2*2*2

#include<stdio.h>
int main()
{
    double base,exp,result = 1, i;

    printf("Enter base : ");
    scanf("%lf",&base);

     printf("Enter exp : ");
    scanf("%lf",&exp);

    //result = pow(base,exp);// using Library function .

     // not using library function
    for(i=0; i<exp; i++)
    {
        result = result*base;
    }
    printf("Result = %.lf",result);


}
