//Write a C Program that that use unary minus operator

#include<stdio.h>
int main()
{
    int result,  x = 10;
    result = -x;

    printf("Result of unary minus Operator = %d",result);

    return 0;
}

