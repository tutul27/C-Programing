//Use of post increment
// ++a;
//increment x by one - before it is used
#include<stdio.h>
int main()
{
    int y, x = 10;

    y = ++x; //y = 11; replace
    printf("x = %d\n",x);
    printf("y = %d\n",y);
    return 0;
}

