//Use of post increment
// --a;
//increment x by one - before it is used

#include<stdio.h>
int main()
{
    int y,x = 10;

    y = --x; //y = 9; replace
    printf("x = %d\n",x); //output x = 9;
    printf("y = %d\n",y);  // output y = 9;
    return 0;
}

