//Write a C Program that reads any integer value and display its absolute value;
#include<stdio.h>
int main()
{
    int result = abs(-25);
    printf(" Absolute value = %d",result);
    return 0;
}
