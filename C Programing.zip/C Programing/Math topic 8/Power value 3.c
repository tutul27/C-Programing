//Write a C Program that read two numbers(x,y) and display the value of x^y;
//pow(x,n)...pow read double type value;
#include<stdio.h>
int main()
{

    /*
    double result = pow(5,3);
    printf("Power value = %.2lf\n",result);
    */

    int x,y;
    printf("Enter x = ");
    scanf("%d",&x);

    printf("Enter y = ");
    scanf("%d", &y);

    double result = pow(x,y);
    printf(" The Power value = %.2lf",result);
    return 0;
}
