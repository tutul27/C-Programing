// Use of strlwr() function;
#include<stdio.h>
int main()
{
    char str[] = "Md Tutul Haque";
     strlwr(str);

     printf("strlwr = %s\n",str);
}
