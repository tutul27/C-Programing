// use strupr() function
#include<stdio.h>
int main()
{
    char str[] = "Md Tutul Haque";
    strupr(str);

    printf("String upper = %s",str);


}
