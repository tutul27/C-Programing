// Concat string using strcat() function;
// describe how a sting add another string;
#include<stdio.h>
int main()
{
    char str1[] = "My name is ";


    strcat(str1,"Md tutul Haque");


    printf("str1 = %s\n",str1);


}

