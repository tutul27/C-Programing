// revers a string using strrev() function;
#include<stdio.h>
int main()
{

    char str1[] = "I am Md Tutul Haque";
    printf("str1 = %s\n",str1);

    strrev(str1);
    printf("Revers str1 = %s\n",str1);
}
