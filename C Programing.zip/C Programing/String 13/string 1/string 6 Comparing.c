// Comparing string using strcmp() function
// check two string equal or not;
#include<stdio.h>
int main()
{
    char str1[] = "Tutul Haque";
    char str2[] = "Tutul Haque";
    int d = strcmp(str1,str2);

    if(d==0)
    {
        printf("Strings are equal ");
    }
    else
        printf("Strings are not  equal ");



    return 0;
}
