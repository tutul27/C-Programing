// Concat string  without using strcat() function;
// First finding length first string .then add second string;
#include<stdio.h>
int main()
{
    char str1[] = "My name is ";
    char str2[] = "MD Tutul Haque";

    int i = 0, len = 0, j=0;
    while(str1[i] != '\0')
    {
        i++;
        len++;
    }

    while(str2[j]!='\0')
    {
        str1[len+j] = str2[j];
        j++;
    }

    printf("Str1 = %s\n",str1);

    return 0;

}
