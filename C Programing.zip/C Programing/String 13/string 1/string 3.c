// Finding length of String using strlen() function;
#include<stdio.h>
int main()

{
    char sl[] = "Md Tutul Haque";
    int len = strlen(sl); // using function
    printf("Length = %d\n",len);
}
