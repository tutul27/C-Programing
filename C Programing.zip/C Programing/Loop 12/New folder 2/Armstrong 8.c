//A C Program that checks a number is Armstrong or not;
// 153 = 1^3 + 5^3 + 3^3 = 153; Armstrong;
// 370;
//371, 407;
#include<stdio.h>
int main()
{
    int num,temp,r,sum = 0;
    printf("Enter any integer number : ");
    scanf("%d",&num);

    temp = num;

    while(temp != 0)
    {

        r = temp%10;
        sum = sum + r*r*r;
        temp = temp/10;
    }

    if(sum == num)
        printf("Armstrong\n");
    else
        printf("Not Armstrong\n");

    return 0;
}
