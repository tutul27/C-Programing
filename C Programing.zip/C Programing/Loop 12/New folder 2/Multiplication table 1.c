//Multiplication  table
/*
   Enter number 3;
   3 * 1 = 3;
   3 * 2 = 6
   3 * 3 = 9;
   ......
   ......
   3 * 10 = 30;
*/
#include<stdio.h>
int main()
{
    while(1){
    int num, i;
    printf("Enter the number : ");
    scanf("%d",&num);

    for(i = 1; i <= 10; i++){
            int num1;
        num1 = num * i;
        printf("%d X %d  = %d\n",num,i,num1);
    }

    }

    return 0;
}
