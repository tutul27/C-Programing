// Write a C Program that checks a number is Armstrong 1 to 1000;

#include<stdio.h>
int main()
{
    int initalnum, finalnum, temp, r, sum = 0, i;

    printf("Enter initial number : ");
    scanf("%d",&initalnum);


    printf("Enter final number : ");
    scanf("%d",&finalnum);
    for(i = initalnum; i <= finalnum; i++)
    {
        temp = i;

    while(temp != 0)
    {

        r = temp%10;
        sum = sum + r*r*r;
        temp = temp/10;
    }

    if(sum == i)
    {

        printf("%d\t",i);
    }
    sum = 0;

    }



    return 0;
}



