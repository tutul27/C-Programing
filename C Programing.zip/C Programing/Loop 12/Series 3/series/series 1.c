// 1 + 2 + 3 + .......+ N;
#include<stdio.h>
int main()
{
    int num, sum = 0, i;
    printf("Enter the last number of the series : ");
    scanf("%d",&num);
    printf("1 + 2 + 3 + .......+ %d",num);
    //printf("1 + 2 + 3 + .......+ %d",num);
    //for(i = 1; i <= num; i = i+2)

    for(i = 1; i <= num; i = i+1)
        {
            sum = sum + i;
        }
    printf(" = %d\n",sum);

    return 0;
}
