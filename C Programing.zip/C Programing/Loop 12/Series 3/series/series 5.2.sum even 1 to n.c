
//2+4+6+........+ n(Sum of even numbers 1 to n);print

#include<stdio.h>
int main()
{
    int n, i, sum = 0;
    printf("Enter number n : ");
    scanf("%d",&n);


    printf("2 + 4 + 6 + 8+........%d\n",n);

    for(i = 2; i<=n; i=i+2)
    {
        sum = sum + i;
    }
    printf(" Sum of %d numbers = %d",n,sum);


    return 0;
}
