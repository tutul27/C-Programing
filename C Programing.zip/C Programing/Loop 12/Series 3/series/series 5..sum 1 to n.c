//1+2+3+4+......+ n;
//1+3+5+........+ n;(Sum of odd numbers 1 to n)
//2+4+6+........+ n(Sum of even numbers 1 to n);

#include<stdio.h>
int main()
{
    int n, i, sum = 0;
    printf("Enter number n : ");
    scanf("%d",&n);

    printf("1 + 2 + 3 + 4+........%d\n",n);

    for(i = 1; i<=n; i++)
    {
        sum = sum + i;
    }
    printf(" Sum of %d numbers = %d",n,sum);


    return 0;
}
