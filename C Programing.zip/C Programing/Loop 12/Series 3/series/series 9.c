// 1*2*3*4*5.......N (Sum off 1 to N numbers);
// 1*3*5*7.........N(Sum of odd numbers);
// 2*4*6*8.........N(Sum of Even numbers);

#include<stdio.h>
int main()
{
    int i, n, result = 1;
    printf("Enter n : ");
    scanf("%d",&n);

    printf("1*2*3........%d\n ",n);

    for(i=1; i<=n; i++)  //1*3*5.......=  ;  i=i+2  // 2*4*6.....= ;  i=i+2; result=2;
    {
        result = result * i;
    }

    printf("Result sum of 1 to n numbers = %d",result);
    return 0;
}
