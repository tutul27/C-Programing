// 1+2+3+......+ n;
// 1+3+5+.....+ n;
//2+4+6+......+ n;
// Display  1 to n number ;
// Display  1 to 100 number;
// Display  1 to 100 odd/even number;

#include<stdio.h>
int main()
{
    int n,i;
    printf("Enter number n : ");
    scanf("%d",&n);

    for(i = 1; i <= n; i++)
    {
        printf("%d ",i);
    }
    return 0;
}
