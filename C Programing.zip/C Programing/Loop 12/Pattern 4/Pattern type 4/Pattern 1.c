/*
       1
     2 1
   3 2 1
*/
#include<stdio.h>
int main()
{
    int n, col, row;
    printf("Enter n : ");
    scanf("%d",&n);


    for(row = 1; row <= n; row++)
    {
        // print space
        for(col = 1; col <= n-row; col++)
        {
            printf("  ");
        }
        //printing number;
        for(col = 1; col <= row; col++)
        {
            printf("%d ",col);
        }
        printf("\n");
    }

    return 0;
}
