/*
  A
  B B
  C C C
  D D D D; here we print row;
*/

#include<stdio.h>
int main()
{
    int n, row, col;
    printf("Enter n : ");
    scanf("%d",&n);

    for(row=1; row<=n; row++)
    {
        for(col=1; col<=row; col++)
        {
            printf("%c ",row+64);  // row print;
        }
        printf("\n");
    }

    return 0;
}




