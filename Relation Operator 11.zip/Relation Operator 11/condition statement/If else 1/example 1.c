//Relational operator > , < , >= , <= , ==  , !=   ;
//Control statement - conditional  control statement and loop control statement
// conditional  control statement : if-else, switch ;
#include<stdio.h>
int main()
{
    int num;
    printf("Enter the number any integer : ");
    scanf("%d",&num);

/*
    if(num%2 == 0)
    printf("Even\n");

   if(num%2 != 0)
    printf("Odd);
    */


         if(num%2 == 0)
           {
               printf("Even\n");
           }
           else
            printf("Odd");

    return 0;
}
