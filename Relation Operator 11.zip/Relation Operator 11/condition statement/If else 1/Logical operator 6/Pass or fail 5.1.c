//Write a C Program that read a number and print pass or fail;
#include<stdio.h>
int main()
{
    int marks;

    printf("Enter the marks : ");
    scanf("%d",&marks);

    if(marks >= 33)
    {
        printf(" pass");
    }

    else
        printf("Fail");




    return 0;
}
