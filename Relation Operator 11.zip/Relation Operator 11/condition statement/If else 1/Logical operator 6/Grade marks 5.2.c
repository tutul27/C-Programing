//Write a C Program that take an integer number and print grade
#include<stdio.h>
int main()
{
    int marks;
    printf("Enter the marks : ");
    scanf("%d",&marks);

    if(marks >= 100 || marks <= 0)
    {
        printf("Grade is Invalid");
    }

    else if(marks >= 80 && marks <= 100)
    {
        printf("Grade is A+ ");
    }
    else if(marks >= 70 && marks <= 79)
    {
        printf("Grade is A ");
    }

    else if(marks >= 60 && marks <= 69)
    {
        printf("Grade is A- ");
    }

    else if(marks >= 50 && marks <= 59)
    {
        printf("Grade is B ");
    }

    else if(marks >= 40 && marks <= 49)
    {
        printf("Grade is C ");
    }

   else if(marks >= 33 && marks <= 39)
    {
        printf("Grade is D ");
    }

    else
        printf("Fail");
    return 0;
}
