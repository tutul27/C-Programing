//capital letter   ch>='A' && ch<='Z';
//small letter     ch<='a' && ch<='z'
#include<stdio.h>
int main()
{
    char ch;

    printf("Enter any letter : ");
    scanf("%c",&ch);

    if(ch>='A' && ch<='Z')
    {
        printf("Capital letter");
    }

    else if(ch>='a' && ch<='z')
    {
        printf("Small letter");
    }
    else
    {
        printf("Not a letter");
    }
    return 0;
}
