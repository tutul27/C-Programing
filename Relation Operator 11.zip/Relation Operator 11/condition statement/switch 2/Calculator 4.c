//Write a C Program that calculate ;

#include<stdio.h>>
int main()
{

    double num1, num2;
    char operat;


    printf("Enter an Operator  +, -, *, / : ");
    scanf("%c",&operat);

    printf("Enter two number : ");
    scanf("%lf %lf",&num1,&num2);

    switch(operat)
    {
    case '+' :
        {

        printf("%lf + %lf = %lf\n",num1,num2,num1 + num2);
        break;

    }
    case '-' :
        {
         printf("%lf - %lf = %lf\n",num1,num2,num1 - num2);
         break;

        }

    case '*' :
        {
        printf("%lf * %lf = %lf\n",num1,num2,num1 * num2);
        break;
        }

    case '/' :
        {
            printf("%lf / %lf = %lf\n",num1,num2,num1 / num2);
            break;
        }

    default :
        printf("Not valid");
    return 0;
}

}
