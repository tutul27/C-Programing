#include<stdio.h>
int main()
{
    double num1,num2,result;

    int choice;

    printf("Calculator\n");

    printf("1. Addition\n");
    printf("2. Subtraction \n");
    printf("3. Multiplication \n");
    printf("4. Division \n");

    printf("Enter your choice : \n");
    scanf("%d",&choice);




    switch(choice)
    {
    case 1:
        {
            printf("Enter two number : ");
            scanf("%.2lf %.2lf",&num1,&num2);
            result = num1 + num2;
            printf("Addition = %.2lf\n",result);
            break;
        }

    case 2:
        {
            printf("Enter two number : ");
            scanf("%.2lf %.2lf",&num1,&num2);
            result = num1 - num2;
            printf("Subtraction = %.2lf\n",result);
            break;
        }


    case 3:
        {

            printf("Enter two number : ");
            scanf("%.2lf %.2lf",&num1,&num2);
            result = num1 * num2;
            printf("Multiplication = %.2lf\n",result);
            break;
        }

    case 4:
        {
            printf("Enter two number : ");
            scanf("%.2lf %.2lf",&num1,&num2);
            result = num1 / num2;
            printf("Division = %.2lf\n",result);
            break;
        }
    default :
        printf("Not valid");
    }

    return 0;
}
