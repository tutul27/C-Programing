//Write a C Program that read any integer and display of round(),trunc(),ceil(),floor() function;

#include<stdio.h>
int main()
{
    //use of round();
    /*
    double x = 5.5;
    double result = round(x);
    printf("Round  %.2lf = %.2lf\n",x,result);
    */

    //use of trunc()
    /*
    double x = 5.5;
    double result = trunc(x);
    printf("trunc  %.2lf = %.2lf\n",x,result);//not count point number
    */

    //use of ceil()
   /*
    double x = 5.111;
    double result = ceil(x);
    //display most value ,,,lice x = 5.111; print = 6;
    printf("ceil  %.2lf = %.2lf\n",x,result);
    */

  //use of floor()
    double x = 5.5;
    double result = floor(x);
    printf("floor  %.2lf = %.2lf\n",x,result);


    return 0;
}
