//Write a C Program that read any number x and print log(x);
// use of exp(x) function
// use of sin,cos,cot,tan function
#include<stdio.h>
#include<math.h>
int main()
{
    //use of log(x
    /*
    double x = 10;
    double result = log(x);
    printf("Log(10)  %.2lf = %.2lf",x,result);
    */

    //use of exp(x)
    /*
    double x = 2;
    double result = exp(x);
    printf("exp 2  %.2lf = %.2lf",x,result);
    */


    //use of sin ,cos,tan, cot function
    double x = .35;
    double result = sin(x);
    printf("sin   %.2lf = %.2lf",x,result);


    return 0;
}
