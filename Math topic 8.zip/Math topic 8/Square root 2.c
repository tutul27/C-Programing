//Write a C Program that read two numbers and display its square root;

#include<stdio.h>
int main()
{
   /*
    float result = sqrt(25);
    printf("Square root value = %.2f",result);
    */

    //we take value by user
    double x;
    printf("Enter any number : ");
    scanf("%lf",&x);
    double result = sqrt(x);
    printf("Square root value = %.2lf",result);


    return 0;
}
