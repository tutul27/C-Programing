#include<stdio.h>
int main()
{
    char sl[30];
    printf("Enter your full name : ");
    //scanf("%s".&sl); //scanf() cannot print full sentence

    gets(sl);

    printf("Full name = %s",sl);


    return 0;
}
