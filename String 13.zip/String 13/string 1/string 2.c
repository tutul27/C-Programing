// Display string character-wise;
#include<stdio.h>
int main()
{
    char sl[] = "Suparna";
    int i = 0;

    while(sl[i] != '\0')
    {
        printf("%c\n",sl[i]);
        i++;
    }


    return 0;
}
