// Concat string using strcat() function;
// describe how a sting add another string;
#include<stdio.h>
int main()
{
    char str1[] = "My name is ";
    char str2[] = "Md Tutul Haque";

    strcat(str1,str2);// add ste1+ str2;
    //strcat("str2,str1");// add ste2+ str1;

    printf("str1 = %s\n",str1);


}
