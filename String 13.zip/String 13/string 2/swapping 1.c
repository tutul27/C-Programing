// String swapping
#include<stdio.h>
int main()
{
    char str1[50] = "Bangladesh";
    char str2[50] = "India";
    char temp[50];

    printf("Before swapping : \n");
    printf("str1 = %s\n",str1);
    printf("str2 = %s\n",str2);
    printf("\n");

    strcpy(temp,str1);
    strcpy(str1,str2);
    strcpy(str2,temp);

    printf("After  swapping : \n");
    printf("str1 = %s\n",str1);
    printf("str2 = %s\n",str2);

}
