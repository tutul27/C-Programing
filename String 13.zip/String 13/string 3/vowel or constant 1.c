// A Program that takes a letter and print vowel or constant;

#include<stdio.h>
int main()
{

    char str[100],ch;
    int i,vowel,constant,digit,word,letter,other;

    printf("Enter a string  : ");
    gets(str);

    i=vowel=constant=digit=word=other=0;

    while(ch=str[i] !='\0')
    {
        if(ch=='a' || ch=='o' || ch=='u' || ch=='i' || ch=='e'||
           ch=='A' || ch=='O' || ch=='U' || ch=='I' || ch=='E'
           )
            vowel++;
        else if((ch>='a' && ch<='z') || (ch>='A' && ch<='Z'))
            constant++;
        else if(ch>='0' && ch<='9')
            digit++;
        else if(ch == ' ')
            word++;
        else
            other++;
        i++;
    }
    word++;

    printf("Number of vowels : %d\n",vowel);
    printf("Number of constant : %d\n",constant);
    printf("Number of word : %d\n",word);
    printf("Number of digit : %d\n",digit);
    printf("Number of others : %d\n",other);






}
