//Write a C Program that passing an string to a function;

#include<stdio.h>
void displayString(char sl[])
{
    int i=0;

     while(sl[i] != '\0')
    {
        printf("%c",sl[i]);
        i++;
    }
}
int main()

{
    char str[] = "Md Tutul Haque";
    displayString(str);


}

