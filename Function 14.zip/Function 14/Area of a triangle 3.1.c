// Area of a triangle;

#include<stdio.h>
void triangle(double base, double height)
{

    double area;
    printf("Enter the base  : ");
    scanf("%lf",&base);

    printf("Enter the height  : ");
    scanf("%lf",&height);
    area = .5*base*height;
    printf("Area = %.2lf\n",area);

}




int main()
{

    triangle(base , height);

}

