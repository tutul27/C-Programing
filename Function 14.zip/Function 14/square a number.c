// Square of a number

int square(int a)
{


    printf("The sum is : %d\n",a*a);

}

#include<stdio.h>
int main()
{
    int num,result;
    printf("Enter any integer number : ");
    scanf("%d",&num);

    //result = num * num;
    //printf("Square is : %d\n",result);

    //result = square(num);
    //printf("Square function is : %d",result);*/

     square(num);

}


